<?php
class Productos extends Conectar{

    public function guardarProductos(){
        $conectar=parent::conexion();
        parent::set_names();
        $producto= trim($_POST['producto']);
        $sql="insert into productos values(null,?);";
        $sql=$conectar->prepare($sql); 
        $sql->bindValue(1, $producto);
        $sql->execute();
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Guardado Correctamente  <a href='productos.php'>Mostrar </a>  </center></h2>";        
        exit();
    }

    public function listarProductos(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `productos` ORDER BY `idProducto` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function seleccionarProductos($idProducto){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="select * from productos where idProducto=?";
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1,$idProducto);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
  
    public function editarProductos(){
        $conectar=parent::conexion();
        parent::set_names();
        $idProducto=$_POST["idProducto"];
        $producto=$_POST["producto"]; 
        $sql="UPDATE `productos` SET `producto` = '$producto' WHERE `idProducto` = $idProducto";
        $sql=$conectar->prepare($sql);
        $sql->execute(); 
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Editado Correctamente  <a href='productos.php'>Mostrar </a>  </center></h2>";
        exit(); 
    }

}

?>