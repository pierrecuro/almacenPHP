<?php
  class Marcas extends Conectar{


    public function guardarMarcas(){
        $conectar=parent::conexion();
        parent::set_names();
        $marca= trim($_POST['marca']);
        $sql="insert into marcas values(null,?);";
        $sql=$conectar->prepare($sql); 
        $sql->bindValue(1, $marca);
        $sql->execute();
        $sql->fetch(PDO::FETCH_ASSOC); 
        echo "<h2><center>fue  guardado Correctamente  <a href='marcas.php'>Mostrar </a>  </center></h2>";
        exit();         
    }

    public function listarMarcas(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `marcas` ORDER BY `idMarca` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function seleccionarMarcas($idMarca){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="select * from marcas where idMarca=?";
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1,$idMarca);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
  
    public function editarMarcas(){
        $conectar=parent::conexion();
        parent::set_names();
        $idMarca=$_POST["idMarca"];
        $marca=$_POST["marca"]; 
        $sql="UPDATE `marcas` SET `marca` = '$marca' WHERE `idMarca` = $idMarca";
        $sql=$conectar->prepare($sql);
        $sql->execute(); 
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Editado Correctamente  <a href='marcas.php'>Mostrar </a>  </center></h2>";
        exit(); 
    }






  }

?>