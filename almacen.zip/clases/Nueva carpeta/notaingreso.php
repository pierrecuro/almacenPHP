<?php
class notaIngreso extends Conectar{

    public function guardarAlmacenMateriaPrima(){
        $conectar=parent::conexion();
        parent::set_names();

        $idTipo= trim($_POST['idTipo']);//NI_NS
        $idCategoria=trim($_POST['idCategoria']); 
        $idUnidad=trim($_POST['idUnidad']); 
        $idEmpresa=trim($_POST['idEmpresa']); 
        $numeroSacos=trim($_POST['numeroSacos']);
        $cantidad=trim($_POST['cantidad']);
        $fechaNotaIngreso=date('Y-m-d H:i:s');
        $fechaNotaSalida=date('Y-m-d H:i:s');  
        $idUsuarioNotaIngreso=trim($_POST['idUsuarioNotaIngreso']); 
        $idUsuarioNotaSalida='';  

        $sql="INSERT INTO almacenes VALUES (NULL,?,?,?,?,?,?,?,?,?,?);";
        $sql=$conectar->prepare($sql); 

        $sql->bindValue(1, $idUsuarioNotaIngreso);
        $sql->bindValue(2, $idTipo);//NI_NS
        $sql->bindValue(3, $idCategoria);
        $sql->bindValue(4, $idUnidad); 
        $sql->bindValue(5, $idEmpresa);
        $sql->bindValue(6, $numeroSacos);
        $sql->bindValue(7, $cantidad);
        $sql->bindValue(8, $fechaNotaIngreso);
        $sql->bindValue(9, $fechaNotaSalida);
        $sql->bindValue(10, $idUsuarioNotaSalida);

        $sql->execute();
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Guardado Correctamente  <a href='notaIngresoMateriaPrima.php'>Mostrar </a>  </center></h2>";        
        exit();
    }

    public function listarEmpresas(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `empresas` WHERE `idTipo`='1' ORDER BY `empresas`.`idEmpresa` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }




    public function seleccionarIdAlmacen(){
        $conectar=parent::conexion();
        parent::set_names();
        $idAlmacen=$_GET["idAlmacen"];
        $sql="SELECT * FROM `almacenes` WHERE `idAlmacen`='$idAlmacen'";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listarAlmacenes(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT u.nombre,t.tipo,und.unidad,c.categoria,a.*, e.empresa FROM almacenes a , empresas e,unidades und, categorias c,tipos t,usuarios u where e.idEmpresa=a.idEmpresa and a.idUnidad=und.idUnidad and c.idCategoria=a.idCategoria and a.idUsuarioNotaIngreso=u.id and a.idTipo=t.idTipo and a.idUsuarioNotaSalida='0'";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 

    public function editarAlmacenMateriaPrima(){
        $conectar=parent::conexion();
        parent::set_names();

        $idAlmacen=$_POST["idAlmacen"];
        $idTipo= trim($_POST['idTipo']);//NI_NS
        $idCategoria=trim($_POST['idCategoria']); 
        
        $idUnidad=trim($_POST['idUnidad']); 
        $idEmpresa=trim($_POST['idEmpresa']); 
        $numeroSacos=trim($_POST['numeroSacos']);
        $cantidad=trim($_POST['cantidad']);
        $fechaNotaIngreso=date('Y-m-d H:i:s');
        $fechaNotaSalida=date('Y-m-d H:i:s');  
        $idUsuarioNotaIngreso=trim($_POST['idUsuarioNotaIngreso']); 
        $idUsuarioNotaSalida='0';   

        $sql="UPDATE `almacenes` SET `idEmpresa` = '$idEmpresa',`idCategoria` = '$idCategoria', `idUnidad` = '$idUnidad', `numeroSacos` = '$numeroSacos', `cantidad` = '$cantidad' WHERE `idAlmacen` = $idAlmacen";

        $sql=$conectar->prepare($sql);
        $sql->execute(); 
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Editado Correctamente  <a href='notaIngresoMateriaPrima.php'>Mostrar </a>  </center></h2>";
        exit(); 
    }


    public function listarCategorias(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `categorias` ORDER BY `idCategoria` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function listarUnidades(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `unidades` ORDER BY `idUnidad` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }


/* inicio Lista saldos */
public function saldosNotaSalida(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT u.nombre,t.tipo,und.unidad,c.categoria,a.*, e.empresa FROM almacenes a , empresas e,unidades und, categorias c,tipos t,usuarios u where e.idEmpresa=a.idEmpresa and a.idUnidad=und.idUnidad and c.idCategoria=a.idCategoria and a.idUsuarioNotaSalida=u.id and a.idTipo=t.idTipo";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
}


public function modificarNotaSalida(){
        $conectar=parent::conexion();
        parent::set_names();
        $idUsuarioNotaSalida=$_GET["idUsuarioNotaSalida"];
        $idAlmacen=$_GET["idAlmacen"];    
        $fechaNotaSalida=date('Y-m-d H:i:s');
        $sql="UPDATE `almacenes` SET `idUsuarioNotaSalida` = '$idUsuarioNotaSalida',`fechaNotaSalida` = '$fechaNotaSalida' WHERE `idAlmacen` = $idAlmacen"; 
        $sql=$conectar->prepare($sql);
        $sql->execute(); 
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Editado Correctamente  <a href='notaIngresoMateriaPrima.php'>Mostrar </a>  </center></h2>";
        exit(); 
}

/*  Reporte Saldo - Almacen Materia Prima*/

    public function reportePDF(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT u.nombre,t.tipo,und.unidad,c.categoria,a.*, e.empresa FROM almacenes a , empresas e,unidades und, categorias c,tipos t,usuarios u where e.idEmpresa=a.idEmpresa and a.idUnidad=und.idUnidad and c.idCategoria=a.idCategoria and a.idUsuarioNotaIngreso=u.id and a.idTipo=t.idTipo and a.idUsuarioNotaSalida='0'";  




        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }

}

?>