<?php
class Compras extends Conectar{

    public function guardarCompras(){
        $conectar=parent::conexion();
        parent::set_names();
        $idArticulo= trim($_POST['idArticulo']); 
        $precio= trim($_POST['precio']); 
        $cantidad= trim($_POST['cantidad']); 
        $total=$cantidad*$precio;
        
        $sql="insert into compras values(null,?,?,?,?);";
        $sql=$conectar->prepare($sql); 
        $sql->bindValue(1, $idArticulo);
        $sql->bindValue(2, $precio);
        $sql->bindValue(3, $cantidad);   
        $sql->bindValue(4, $total);      
        $sql->execute();
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Guardado Correctamente  <a href='compras.php'>Mostrar </a>  </center></h2>";        
        exit();
    } 

    public function listarArticulos(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `articulos` ORDER BY `idArticulo` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function listarCompras(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `compras` ORDER BY `idCompra` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }


    public function getProductos(){

        $conectar=parent::conexion();
        parent::set_names();
        
        $sql="SELECT productos.id,productos.producto,productos.precio,
          productos.vig,fotos.name FROM productos,fotos
          WHERE productos.id=fotos.idpro";  
        $sql=$conectar->prepare($sql);
        $sql->execute();

         while ($row=$sql->fetch()) {
            $this->datos[]=$row;
         }

         return $this->datos;
    }



    public function getProductosPorId($id=null){

        $conectar=parent::conexion();
        parent::set_names();
            $id=(int)$id;
          //validacion para que solo se pueda entrar a alchivo pro.php via get sino se
           //redireciona llamanedo el metodo _redirect();.

            if (empty($id) OR !$id) {

                  $this->_redirect();
            }

            $stm=$this->conectar->prepare("SELECT productos.id,productos.producto,productos.precio,
                                             productos.vig,productos.empresa,productos.idioma,productos.edad,productos.video,
                                             fotos.name FROM productos,fotos WHERE productos.id=fotos.idpro
                                             AND productos.id='".$id."'");
            $stm->execute();

            while ($row=$stm->fetch())
            {
              $this->datos[]=$row;
            }

            //validacion de get para detos que sean superior a los id de db
           if (empty($this->datos)){
               $this->_redirect();
           }
           //***********************************************

            return $this->datos;
    }



    public function carro(){

        $conectar=parent::conexion();
        parent::set_names();

            if (isset($_GET["id"])) {
                  $id=strip_tags($_GET["id"]);
            }else{
                  $id=1;
            }

            if (isset($_GET["action"])) {
                      $action=strip_tags($_GET["action"]);
            }else{
              $action="";
            }

            //*********************************
            if (isset($_GET["su"])) {

                  $valor=strip_tags($_GET["su"]);
                  $valor=(int)$valor;

                  if ($valor==0 OR $valor=='' OR !$valor) {

                        $action='removeProd';
                  }

            }else{
             $valor=0;
            }

            //**********************************
            switch ($action) {
                    case 'sum':
                         if (isset($_SESSION["carro"][$id])) {

                                $_SESSION["carro"][$id]=$valor;
                        }else{
                                $_SESSION["carro"][$id]=1;
                        }

                    break;

                    case 'add':
                        if(isset($_SESSION["carro"][$id]))

                                 $_SESSION["carro"][$id]++;
                        else
                                 $_SESSION["carro"][$id]=1;
                    break;

                    case 'remove':

                        if (isset($_SESSION["carro"][$id])) {

                                    $_SESSION["carro"][$id]--;

                                if ($_SESSION["carro"][$id]==0) {

                                          unset($_SESSION["carro"][$id]);
                                }
                        }

                    break;

                    case 'removeProd':
                        if (isset($_SESSION["carro"][$id])) {

                                  unset($_SESSION["carro"][$id]);
                        }

                    break;

                    case 'empty':
                           unset($_SESSION["carro"][$id]);

                    break;
            }
       }
 
 
}

?>