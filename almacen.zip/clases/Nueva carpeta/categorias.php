<?php
class Categorias extends Conectar{

    public function guardarCategorias(){
        $conectar=parent::conexion();
        parent::set_names();
        $categoria= trim($_POST['categoria']);
        $sql="insert into categorias values(null,?);";
        $sql=$conectar->prepare($sql); 
        $sql->bindValue(1, $categoria);
        $sql->execute();
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Guardado Correctamente  <a href='categorias.php'>Mostrar </a>  </center></h2>";        
        exit();
    }

    public function listarCategorias(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `categorias` ORDER BY `idCategoria` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function seleccionarCategorias($idCategoria){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="select * from categorias where idCategoria=?";
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1,$idCategoria);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
  
    public function editarCategorias(){
        $conectar=parent::conexion();
        parent::set_names();
        $idCategoria=$_POST["idCategoria"];
        $categoria=$_POST["categoria"]; 
        $sql="UPDATE `categorias` SET `categoria` = '$categoria' WHERE `idCategoria` = $idCategoria";
        $sql=$conectar->prepare($sql);
        $sql->execute(); 
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Editado Correctamente  <a href='categorias.php'>Mostrar </a>  </center></h2>";
        exit(); 
    }

}

?>