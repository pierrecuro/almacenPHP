<?php
class Articulos extends Conectar{

    public function guardarArticulos(){
        $conectar=parent::conexion();
        parent::set_names();
        $articulo= trim($_POST['articulo']);
        $idMarca=$_POST['idMarca'];
        $idCategoria=$_POST['idCategoria'];
        $idUnidad=$_POST['idUnidad'];
        $precioCompra=$_POST['precioCompra'];
        $precioVenta=$_POST['precioVenta'];
        $codigo="";
        $foto="";

        $sql="insert into articulos values(null,?,?,?,?,?,?,?,?);";
        $sql=$conectar->prepare($sql); 
        $sql->bindValue(1, $idMarca);
        $sql->bindValue(2, $idCategoria);
        $sql->bindValue(3, $idUnidad); 
        $sql->bindValue(4, $articulo);
        $sql->bindValue(5, $precioCompra);
        $sql->bindValue(6, $precioVenta);
        $sql->bindValue(7, $codigo);
        $sql->bindValue(8, $foto);
        $sql->execute();
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Guardado Correctamente  <a href='articulos.php'>Mostrar </a>  </center></h2>";        
        exit();
    }

    public function editarArticulos(){
        $conectar=parent::conexion();
        parent::set_names();
        $idArticulo=$_POST["idArticulo"];
        $articulo=$_POST["articulo"]; 
        $idMarca=$_POST['idMarca'];
        $idCategoria=$_POST['idCategoria'];
        $idUnidad=$_POST['idUnidad'];
        $precioCompra=$_POST['precioCompra'];
        $precioVenta=$_POST['precioVenta'];
        
        $sql="UPDATE `articulos` SET `articulo` = '$articulo',`idMarca` = '$idMarca',`idCategoria` = '$idCategoria',`idUnidad` = '$idUnidad',`precioCompra` = '$precioCompra',`precioVenta` = '$precioVenta' WHERE `idArticulo` = $idArticulo";

        
        $sql=$conectar->prepare($sql);
        $sql->execute(); 
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Editado Correctamente  <a href='Articulos.php'>Mostrar </a>  </center></h2>";
        exit(); 
    }
    public function listarMarcas(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `marcas` ORDER BY `idMarca` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function listarCategorias(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `categorias` ORDER BY `idCategoria` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function listarUnidades(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `unidades` ORDER BY `idUnidad` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function listarArticulos(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `articulos` ORDER BY `idArticulo` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function seleccionarArticulos($idArticulo){
        $conectar=parent::conexion();
        parent::set_names();
        $sql=" select a.*,m.* ,c.* ,u.* from articulos a, marcas m, categorias c, unidades u where a.idArticulo=? and a.idMarca=m.idMarca and a.idCategoria=c.idCategoria and a.idUnidad=u.idUnidad ";
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1,$idArticulo);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
  


}

?>