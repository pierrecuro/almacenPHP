<?php
class Reportes extends Conectar{
 
    public function reportePDFNotaIngreso(){
            $conectar=parent::conexion();
            parent::set_names();
            $sql="SELECT DISTINCT(ni.idProducto) as idProducto,p.producto,SUM(ni.cantidad) as cantidad ,SUM(ni.numeroSacos) as numeroSacos FROM notasingresos ni, productos p where ni.idProducto=p.idProducto  GROUP BY ni.idProducto";
            $sql=$conectar->prepare($sql);
            $sql->execute();
            return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }  

    public function reportePDFNotaSalida(){
            $conectar=parent::conexion();
            parent::set_names();
            $sql="SELECT DISTINCT(ns.idProducto) as idProducto,p.producto,SUM(ns.cantidad) as cantidad ,SUM(ns.numeroSacos) as numeroSacos    FROM notassalidas ns, productos p where ns.idProducto=p.idProducto   GROUP BY ns.idProducto";
            $sql=$conectar->prepare($sql);
            $sql->execute();
            return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function reporteDistinct(){
            $conectar=parent::conexion();
            parent::set_names();
            $sql=$conectar->prepare("SELECT DISTINCT(idProducto) FROM `notasingresos`"); 
            $sql=$conectar->prepare($sql);
            $sql->execute();
            return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }    


    public function reporte(){
            $conectar=parent::conexion();
            parent::set_names();
/*
    $gsent = $conectar->prepare("SELECT DISTINCT(idProducto) FROM `notasingresos`");
    $gsent->execute(); 
    while($rows=$gsent->FETCH(PDO::FETCH_ASSOC)){
        $sql="CALL stock(".$rows['idProducto'].")"; 
        //$response[] = array("value"=>$rows['codigoArticulo'],"label"=>$rows['articulo']);
    } 
*/
           // $sqlDistinct=$conectar->prepare("SELECT DISTINCT(idProducto) FROM `notasingresos`"); 
            $sql="CALL stock(1)"; 
            $sql=$conectar->prepare($sql);            
            $sql->execute();
            return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }    



/*

  Reporte Saldo - Almacen Materia Prima

    public function reportePDF(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT u.nombre,t.tipo,und.unidad,c.categoria,a.*, e.empresa FROM notasingresos a , empresas e,unidades und, categorias c,tipos t,usuarios u where e.idEmpresa=a.idEmpresa and a.idUnidad=und.idUnidad and c.idCategoria=a.idCategoria and a.idUsuarioNotaIngreso=u.id and a.idTipo=t.idTipo and a.idUsuarioNotaSalida='0'";   

        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
*/
}

?>