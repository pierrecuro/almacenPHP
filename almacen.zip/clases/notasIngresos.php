<?php
class NotasIngresos extends Conectar{

    public function guardarNotaIngreso(){
        $conectar=parent::conexion();
        parent::set_names(); 

        $idUsuario=trim($_POST['idUsuario']);
        $idTipo= trim($_POST['idTipo']);//NI_NS
        $idProducto=trim($_POST['idProducto']); 
        $idUnidad=trim($_POST['idUnidad']); 
        $idEmpresa=trim($_POST['idEmpresa']); 
        $numeroSacos=trim($_POST['numeroSacos']);
        $cantidad=trim($_POST['cantidad']);
        $fechaNotaIngreso=date('Y-m-d H:i:s'); 
        $seguimiento='';  
        $sql="INSERT INTO notasingresos VALUES (NULL,?,?,?,?,?,?,?,?,?);";
        $sql=$conectar->prepare($sql); 
        $sql->bindValue(1, $idUsuario);
        $sql->bindValue(2, $idTipo);//NI_NS
        $sql->bindValue(3, $idProducto);
        $sql->bindValue(4, $idUnidad); 
        $sql->bindValue(5, $idEmpresa);
        $sql->bindValue(6, $numeroSacos);
        $sql->bindValue(7, $cantidad);
        $sql->bindValue(8, $fechaNotaIngreso);  
        $sql->bindValue(9, $seguimiento);  
        $sql->execute();
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Guardado Correctamente  <a href='notasIngresos.php'>Mostrar </a>  </center></h2>";        
        exit();
    }

    public function listarNotasIngresos(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT u.nombre,t.tipo,und.unidad,p.producto,ni.*, e.empresa FROM notasingresos ni , empresas e,unidades und, productos p,tipos t,usuarios u where e.idEmpresa=ni.idEmpresa and ni.idUnidad=und.idUnidad and p.idProducto=ni.idProducto and ni.idUsuario=u.id and ni.idTipo=t.idTipo";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 

    public function listarEmpresas(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `empresas` WHERE `idTipo`='1' ORDER BY `empresas`.`idEmpresa` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    } 

    public function seleccionaridNotaIngreso(){
        $conectar=parent::conexion();
        parent::set_names();
        $idNotaIngreso=$_GET["idNotaIngreso"];
        $sql="SELECT * FROM `notasingresos` WHERE `idNotaIngreso`='$idNotaIngreso'";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    } 

    public function editarNotasIngresos(){
        $conectar=parent::conexion();
        parent::set_names();

        $idNotaIngreso=$_POST["idNotaIngreso"];
        $idTipo= trim($_POST['idTipo']);//NI_NS
        $idProducto=trim($_POST['idProducto']);  
        $idUnidad=trim($_POST['idUnidad']); 
        $idEmpresa=trim($_POST['idEmpresa']); 
        $numeroSacos=trim($_POST['numeroSacos']);
        $cantidad=trim($_POST['cantidad']);
        $fechaNotaIngreso=date('Y-m-d H:i:s'); 
        $idUsuario=trim($_POST['idUsuario']); 
        $seguimiento=trim($_POST['seguimiento'])." - ( idUsuario: ".$idUsuario." / Fecha: ".$fechaNotaIngreso.")"; 
 
        $sql="UPDATE `notasingresos` SET   `idTipo` = '$idTipo', `idProducto` = '$idProducto', `idUnidad` = '$idUnidad', `idEmpresa` = '$idEmpresa', `numeroSacos` = '$numeroSacos', `cantidad` = '$cantidad' , `seguimiento` = '$seguimiento' WHERE `idNotaIngreso` = '$idNotaIngreso'";

        $sql=$conectar->prepare($sql);
        $sql->execute(); 
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Editado Correctamente  <a href='notasIngresos.php'>Mostrar </a>  </center></h2>";
        exit(); 
    }


    public function listarProductos(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `productos` ORDER BY `idProducto` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function listarUnidades(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `unidades` ORDER BY `idUnidad` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
     

 
}

?>