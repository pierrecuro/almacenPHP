<?php
class Empresas extends Conectar{

    public function guardarEmpresas(){
        $conectar=parent::conexion();
        parent::set_names();
        $empresa= trim($_POST['empresa']);
        $idTipo= trim($_POST['idTipo']);
        $ruc= trim($_POST['ruc']);
        $direccion= trim($_POST['direccion']);
        $celular= trim($_POST['celular']);
        $correo= trim($_POST['correo']);
        $datos= trim($_POST['datos']);
  
        $sql="insert into empresas values(null,?,?,?,?,?,?,?);"; 
        $sql=$conectar->prepare($sql); 
        $sql->bindValue(1, $idTipo);
        $sql->bindValue(2, $empresa);
        $sql->bindValue(3, $ruc);
        $sql->bindValue(4, $direccion);
        $sql->bindValue(5, $celular);
        $sql->bindValue(6, $correo);
        $sql->bindValue(7, $datos); 

        $sql->execute();
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Guardado Correctamente  <a href='empresas.php'>Mostrar </a>  </center></h2>";        
        exit();
    }

    public function listarTipo(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `tipos` WHERE tabla='personas'";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
    public function listarEmpresas(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT e.*,t.tipo FROM empresas e, tipos t WHERE  e.idTipo=t.idTipo";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function seleccionarEmpresas($idEmpresa){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="select * from empresas where idEmpresa=?";
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1,$idEmpresa);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
  
    public function editarEmpresas(){
        $conectar=parent::conexion();
        parent::set_names();
        $idEmpresa=$_POST["idEmpresa"];
        $empresa= trim($_POST['empresa']);
        $idTipo= $_POST['idTipo'];
        $ruc= trim($_POST['ruc']);
        $direccion= trim($_POST['direccion']);
        $celular= trim($_POST['celular']);
        $correo= trim($_POST['correo']);
        $datos= trim($_POST['datos']); 


        $sql="UPDATE `empresas` SET  `idTipo` = '$idTipo',`empresa` = '$empresa', `ruc` = '$ruc', `direccion` = '$direccion', `celular` = '$celular', `correo` = '$correo', `datos` = '$datos' WHERE `idEmpresa` = $idEmpresa";
        $sql=$conectar->prepare($sql);
        $sql->execute(); 
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Editado Correctamente  <a href='empresas.php'>Mostrar </a>  </center></h2>";
        exit(); 
    }

}

?>