<?php
  class Usuarios extends Conectar{

    
  	  public function login(){
  	  	 $conectar=parent::conexion();
  	  	 parent::set_names();

  	  	 if(empty($_POST["usuario"]) and empty($_POST["password"])){
           header("Location:".Conectar::url()."/index.php");
           exit();
  	  	 }

  	  	 $sql="select * from usuarios where usuario=? and password=?";

  	  	 $sql=$conectar->prepare($sql);

  	  	 $sql->bindValue(1, $_POST["usuario"]);
  	  	 $sql->bindValue(2, $_POST["password"]);
  	  	 $sql->execute();
  	  	 $resultado=$sql->fetch(PDO::FETCH_ASSOC);

  	  	 if(is_array($resultado)==true and count($resultado)>=1){
           
           $_SESSION["backend_id"]=$resultado["id"];
           $_SESSION["nombre"]=$resultado["nombre"];
           $_SESSION["usuario"]=$resultado["usuario"];
           $_SESSION["cedula"]=$resultado["cedula"];

           header("Location:".Conectar::url()."/inicio.php");
           exit();
  	  	 
  	  	 }else{

  	  	 	header("Location:".Conectar::url()."/index.php");
  	  	 	exit();
  	  	 }
  	  }

  }

?>