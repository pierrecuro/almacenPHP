<?php
class Unidades extends Conectar{

    public function guardarUnidades(){
        $conectar=parent::conexion();
        parent::set_names();
        $unidad= trim($_POST['unidad']);
        $sql="insert into unidades values(null,?);";
        $sql=$conectar->prepare($sql); 
        $sql->bindValue(1, $unidad);
        $sql->execute();
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Guardado Correctamente  <a href='unidades.php'>Mostrar </a>  </center></h2>";        
        exit();
    }

    public function listarUnidades(){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM `unidades` ORDER BY `idUnidad` DESC";  
        $sql=$conectar->prepare($sql);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function seleccionarUnidades($idUnidad){
        $conectar=parent::conexion();
        parent::set_names();
        $sql="select * from unidades where idUnidad=?";
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1,$idUnidad);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
    }
  
    public function editarUnidades(){
        $conectar=parent::conexion();
        parent::set_names();
        $idUnidad=$_POST["idUnidad"];
        $unidad=$_POST["unidad"]; 
        $sql="UPDATE `unidades` SET `unidad` = '$unidad' WHERE `idUnidad` = $idUnidad";
        $sql=$conectar->prepare($sql);
        $sql->execute(); 
        $sql->fetch(PDO::FETCH_ASSOC);
        echo "<h2><center>fue  Editado Correctamente  <a href='unidades.php'>Mostrar </a>  </center></h2>";
        exit(); 
    }

}

?>