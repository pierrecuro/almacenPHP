DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `stock`(`pIdproducto` INT)
BEGIN
		declare cantSacos_ingre decimal(5,2);
		declare cantidad_ingre decimal(5,2);
		declare cantSacos_sal decimal(5,2);
		declare cantidad_sal decimal(5,2);
		declare cantidadSacosDisponible decimal(5,2);
		declare cantidadDisponible decimal(5,2);
		
		declare productoStock nvarchar(250);

		SELECT SUM(numeroSacos) FROM notasingresos WHERE idProducto=pIdproducto INTO cantSacos_ingre;
		SELECT SUM(cantidad) FROM notasingresos WHERE idProducto=pIdproducto  INTO cantidad_ingre;
		SELECT SUM(numeroSacos) FROM notassalidas WHERE idProducto=pIdproducto INTO cantSacos_sal;
		SELECT SUM(cantidad) FROM notassalidas WHERE idProducto=pIdproducto  INTO cantidad_sal;

		SELECT producto FROM productos WHERE idProducto=pIdproducto  INTO productoStock;
		
		SET cantidadSacosDisponible=cantSacos_ingre-cantSacos_sal;
		SET cantidadDisponible=cantidad_ingre-cantidad_sal;
		SELECT productoStock,cantidadSacosDisponible,cantidadDisponible;
    END$$
DELIMITER ;
