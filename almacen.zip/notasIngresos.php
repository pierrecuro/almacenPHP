<?php
require 'config/htmlCabeza.php'; 
require_once("clases/notasIngresos.php"); 
//print_r( $_POST );  
//print_r( $_GET);  
$interfaces=new NotasIngresos(); 

$rproducto=$interfaces->listarProductos(); 
$runidad=$interfaces->listarUnidades(); 
$rempresa=$interfaces->listarEmpresas(); 
$datos=$interfaces->listarNotasIngresos();

if(isset($_POST["Guardar"])  ){ $interfaces->guardarNotaIngreso(); } 
if(isset($_GET["idNotaIngreso"])){ $info=$interfaces->seleccionaridNotaIngreso(); } 
if(isset($_POST["Editar"])  ){ $interfaces->editarNotasIngresos(); } 

?>


<!-- Inicio Formulario  -->


<div class="col-lg-8">
    <div class="card">
        <div class="card-header">nota Ingreso</div>
        <div class="card-body card-block">



        <form action="" method="post" class=""> 
                <div class="col-lg-6">
                    <div class="form-group">
                        <div class="input-group"> 
                        <div class="input-group-addon">N° Sacos</div>
                            <input type="hidden"  name="idTipo"  value='3' >
                            <input type="hidden"  name="idUsuario"  value='<?php echo $idUsuario;?>' >
                    <input type="hidden"  name="seguimiento"  value='<?php echo $info[0]["seguimiento"];?>' >
                            <input type="text" id="numeroSacos" name="numeroSacos" placeholder="Numero de sacos"
                            <?php if(isset($_GET["idNotaIngreso"])){ echo "value='".$info[0]["numeroSacos"]."'"; }?>
                            class="form-control" required="required">
                        </div>
                    </div>    
                </div>     

                <div class="col-lg-5">   
                    <div class="form-group">
                        <div class="input-group"> 
                        <div class="input-group-addon">Cantidad</div>
                        <input type="text" id="Cantidad" name="cantidad" placeholder="Cantidad"
                        <?php if(isset($_GET["idNotaIngreso"])){ echo "value='".$info[0]["cantidad"]."'"; }?>
                        class="form-control" required="required">
                        </div> 

                        <select name='idUnidad'   class="standardSelect"  >
                        <?php for($i=0;$i<sizeof($runidad);$i++){?>
                        <option value="<?php echo $runidad[$i]["idUnidad"];?>"
                        <?php if(isset($_GET["idArticulo"])){ if ($info[0]["idUnidad"]==$runidad[$i]["idUnidad"]){echo  "selected"; } }?>
                        >
                        <?php echo $runidad[$i]["unidad"];?></option><?php } ?> 
                        </select> 
                    </div>   
                </div> 

                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Proveedor / Agricultor</strong>
                        </div>
                        <div class="card-body"> 
                            <select name='idEmpresa'  class="standardSelect" >
                                <?php for($i=0;$i<sizeof($rempresa);$i++){?>
                                    <option value="<?php echo $rempresa[$i]["idEmpresa"];?>"
                                    <?php if(isset($_GET["idNotaIngreso"])){ if ($info[0]["idEmpresa"]==$rempresa[$i]["idEmpresa"]){echo  "selected"; } }?>
                                    >
                                    <?php echo $rempresa[$i]["empresa"];?>
                                    </option>
                                <?php } ?> 
                            </select>
                        </div>
                    </div>
                </div> 
 
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Producto</strong> 
                        </div>
                        <div class="card-body"> 
                            <select name='idProducto' class="standardSelect" >
                                    <?php for($i=0;$i<sizeof($rproducto);$i++){?>
                                    <option value="<?php echo $rproducto[$i]["idProducto"];?>"
                                    <?php if(isset($_GET["idNotaIngreso"])){ if ($info[0]["idProducto"]==$rproducto[$i]["idProducto"]){echo  "selected"; } }?>
                                    >
                                    <?php echo $rproducto[$i]["producto"];?></option><?php } ?> 
                            </select>
                        </div>
                    </div>
                </div>    

                <div class="form-actions form-group">
                    <?php if(isset($_GET["idNotaIngreso"])){ ?>
                        <input type="hidden"  name="idNotaIngreso" value="<?php echo $info[0]["idNotaIngreso"]; ?>"  >
                        <button type="submit" class="btn btn-success btn-sm" name="Editar">Editar</button>
                    <?php } else {?>
                    <button type="submit" class="btn btn-success btn-sm" name="Guardar" >Guardar</button>
                    <?php } ?>
                </div> 
        </form>


                </div>
        </div>
    </div>
</div>

      
<!-- Fin Formulario  -->
 

<!-- Inicio Contenidos  -->
        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Listado de la Notas Ingreso</strong> 
                               
                                <a class="btn btn-primary" target="_blank" onclick"this.document.location.href="reportesPDF/notaIngreso.php" ;"="" href="reportesPDF/notaIngreso.php">Reporte Nota de Ingreso PDF</a>

 

                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr> 
                                            <th>Proveedor / Agricultor</th> 
                                            <th>Numero Sacos</th> 
                                            <th>Cantidad</th> 
                                            <th>Unidad</th> 
                                            <th>producto</th> 
                                            <th>fechaNotaIngreso</th>  
                                            <th>nombre de quien realizo la Nota Ingreso</th> 
                                            <th>Editar</th> 
                                        </tr>
                                    </thead>
                                    <tbody> 
                                        <?php for($i=0;$i<sizeof($datos);$i++){?> 
                                         <tr>                   
                                            <td><?php echo $datos[$i]["empresa"];?></td> 
                                            <td><?php echo $datos[$i]["numeroSacos"];?></td> 
                                            <td><?php echo $datos[$i]["cantidad"];?></td> 
                                            <td><?php echo $datos[$i]["unidad"];?></td> 
                                            <td><?php echo $datos[$i]["producto"];?></td> 
                                            <td><?php echo $datos[$i]["fechaNotaIngreso"];?></td> 
                                            <td><?php echo $datos[$i]["nombre"];?></td>  
                                       <td><a href='notasIngresos.php?idNotaIngreso=<?php echo $datos[$i]["idNotaIngreso"];?>'> Editar </a></td></tr>
                                        <?php } ?>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
<!-- Final Contenidos  -->

<?php
require 'config/htmlPie.php';
?>
