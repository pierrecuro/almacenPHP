<?php
require 'config/htmlCabeza.php'; 
require_once("clases/unidades.php"); 
//print_r( $_POST );  
//print_r( $_GET);  
$interfaces=new Unidades(); 
$datos=$interfaces->listarUnidades();
if(isset($_GET["idUnidad"])){ $info=$interfaces->seleccionarUnidades($_GET["idUnidad"]); } 
if(isset($_POST["Guardar"]) and $_POST["unidad"]!='' ){ $interfaces->guardarUnidades(); } 
if(isset($_POST["Editar"])){ $interfaces->editarUnidades(); }  
?>


<!-- Inicio Formulario  -->
<div class="col-lg-6">
    <div class="card">
        <div class="card-header">Unidades</div>
        <div class="card-body card-block">
            <form action="" method="post" class="">
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon"><i class="fa fa-user"></i></div>
                        <input type="text" id="Unidades" name="unidad" placeholder="unidad"
                        <?php if(isset($_GET["idUnidad"])){ echo "value='".$info[0]["unidad"]."'"; }?>
                        class="form-control" required="required">
                    </div>
                </div>
                <div class="form-actions form-group">
                    <?php if(isset($_GET["idUnidad"])){ ?>
                        <input type="hidden"  name="idUnidad" value="<?php echo $info[0]["idUnidad"]; ?>"  >
                        <button type="submit" class="btn btn-success btn-sm" name="Editar">Editar</button>
                    <?php } else {?>
                    <button type="submit" class="btn btn-success btn-sm" name="Guardar">Guardar</button>
                    <?php } ?>
            	</div>
            </form>
        </div>
    </div>
</div>
<!-- Fin Formulario  -->


<!-- Inicio Contenidos  -->
        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Listado de la unidad</strong>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr> 
                                            <th>Unidades</th> 
                                            <th>Editar</th> 
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php for($i=0;$i<sizeof($datos);$i++){?> 
                                         <tr> 
                                            <td><?php echo $datos[$i]["unidad"];?></td> 
                                       <td><a href='unidades.php?idUnidad=<?php echo $datos[$i]["idUnidad"];?>'> Editar </a></td></tr>
                                        <?php } ?>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
<!-- Final Contenidos  -->

<?php
require 'config/htmlPie.php';
?>
