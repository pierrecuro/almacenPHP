<?php
require('../fpdf.php');

$pdf = new FPDF();
//$pdf->AddPage();
$pdf->AliasNbPages();
$pdf->AddPage();
//$pdf->Image('c.png',1025,10);
$pdf->Image('c.png',0,0,300,0,'PNG');
//$pdf->Image('c.png',60,30,90,0,'PNG');

//$pdf->Image('c.png',0);
$pdf->SetFont('Arial','B',16);
$pdf->Cell(40,10,'�Hola, Mundo!');
$pdf->Output();
?>