<?php
require('../fpdf.php');

$pdf = new FPDF('L','mm',array(212.26,297.01)); //tamaño de pagina Horizontal
$pdf->AddPage();
$pdf->SetFont('Times','',12);
$pdf->Image('c.png',0,0,300,0,'PNG');

$pdf->SetFont('Arial','B',30);
$pdf->Cell(5);
$pdf->Cell(0,85,'Pierre Curo Quispe',0,0,'C');


$pdf->SetFont('Arial','B',11);
//$pdf->SetFillColor(153,255,100);
$pdf->SetTextColor(85,81,82);

$pdf->SetXY(65, 171);
$pdf->Cell(0,0,'07 de Enero del 2020');
$pdf->SetXY(65, 180);
$pdf->Cell(0, 0, '2020-IBMSPSS40025421'); //Celda

$pdf->Output();
?>

