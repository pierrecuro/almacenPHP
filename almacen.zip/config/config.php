<?php
session_start();

class Conectar{
        protected $dbh;
        
        protected function conexion(){

        //$conectar= $this->dbh= new PDO("mysql:local=localhost; dbname=procompite_com","root2014","40025421@C4r0"); 
        $conectar= $this->dbh= new PDO("mysql:local=localhost; dbname=almacen","root",""); 
        return $conectar;
        }
        public function set_names(){
          return $this->dbh->query("SET NAMES 'utf8'");
        }
        public function url(){
          //return 'http://www.universitylearn.com/procompite.com';
          return 'http://localhost:90';
          
        }
        public function ruta(){
          //return 'http://www.universitylearn.com/procompite.com';
          return 'http://localhost:90';
        }
} 
?>