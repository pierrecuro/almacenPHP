-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 01-07-2020 a las 22:11:32
-- Versión del servidor: 5.6.47-cll-lve
-- Versión de PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `procompite_com`
--

DELIMITER $$
--
-- Procedimientos
--
$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `almacenes`
--

CREATE TABLE `almacenes` (
  `idAlmacen` int(11) NOT NULL,
  `idUsuarioNotaIngreso` int(11) DEFAULT NULL,
  `idTipo` int(11) DEFAULT NULL,
  `idCategoria` int(11) DEFAULT NULL,
  `idUnidad` int(11) DEFAULT NULL,
  `idEmpresa` int(11) DEFAULT NULL,
  `numeroSacos` float(5,2) DEFAULT NULL,
  `cantidad` float(5,2) DEFAULT NULL,
  `fechaNotaIngreso` datetime DEFAULT NULL,
  `fechaNotaSalida` datetime DEFAULT NULL,
  `idUsuarioNotaSalida` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `almacenes`
--

INSERT INTO `almacenes` (`idAlmacen`, `idUsuarioNotaIngreso`, `idTipo`, `idCategoria`, `idUnidad`, `idEmpresa`, `numeroSacos`, `cantidad`, `fechaNotaIngreso`, `fechaNotaSalida`, `idUsuarioNotaSalida`) VALUES
(1, 1, 3, 1, 1, 2, 2.00, 2.43, '2019-09-11 00:10:12', '2019-09-11 00:10:12', 0),
(2, 1, 3, 1, 1, 1, 2.00, 2.58, '2019-09-11 00:10:46', '2019-09-11 00:10:46', 0),
(3, 1, 3, 1, 1, 1, 4.00, 3.01, '2019-09-11 00:11:10', '2019-09-11 00:11:10', 0),
(4, 1, 3, 1, 1, 2, 1.00, 1.22, '2019-09-11 00:11:27', '2019-09-11 00:11:27', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas`
--

CREATE TABLE `empresas` (
  `idEmpresa` int(5) NOT NULL,
  `idTipo` int(5) DEFAULT NULL,
  `empresa` varchar(60) NOT NULL,
  `ruc` varchar(11) DEFAULT NULL,
  `direccion` varchar(80) DEFAULT NULL,
  `celular` varchar(9) DEFAULT NULL,
  `correo` varchar(80) DEFAULT NULL,
  `datos` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `empresas`
--

INSERT INTO `empresas` (`idEmpresa`, `idTipo`, `empresa`, `ruc`, `direccion`, `celular`, `correo`, `datos`) VALUES
(1, 2, 'CHACMANI JIMENEZ WASHINGTON', '10249902298', 'Av, Edgar de La Torre 423', '984941017', '', ''),
(2, 1, 'PIMENTEL CONDORI LUDGARDO', '10445566125', 'Av. Edgar de la torre 1210', '984941017', '', ''),
(3, 1, 'AGRICOLA ALSUR CUSCO S.A.C.', '20564022765', 'Urb. Tres Reyes Nro. S/n C.C. Markjo (Sector Sangarara Fca Alsur) - Anta', '987890452', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notasingresos`
--

CREATE TABLE `notasingresos` (
  `idNotaIngreso` int(11) NOT NULL,
  `idUsuario` int(11) DEFAULT NULL,
  `idTipo` int(11) DEFAULT NULL,
  `idProducto` int(11) DEFAULT NULL,
  `idUnidad` int(11) DEFAULT NULL,
  `idEmpresa` int(11) DEFAULT NULL,
  `numeroSacos` float(5,2) DEFAULT NULL,
  `cantidad` float(5,2) DEFAULT NULL,
  `fechaNotaIngreso` datetime DEFAULT NULL,
  `seguimiento` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `notasingresos`
--

INSERT INTO `notasingresos` (`idNotaIngreso`, `idUsuario`, `idTipo`, `idProducto`, `idUnidad`, `idEmpresa`, `numeroSacos`, `cantidad`, `fechaNotaIngreso`, `seguimiento`) VALUES
(1, 1, 3, 1, 1, 2, 2.00, 2.43, '2019-09-11 00:10:12', '- ( idUsuario: 1 / Fecha: 2019-09-12 06:20:54) - ( idUsuario: 1 / Fecha: 2019-09-12 06:35:43) - ( idUsuario: 1 / Fecha: 2019-09-14 00:35:39)'),
(2, 1, 3, 1, 1, 2, 2.00, 2.58, '2019-09-11 00:10:46', '- ( idUsuario: 1 / Fecha: 2019-09-14 00:02:51) - ( idUsuario: 1 / Fecha: 2019-09-14 00:10:45) - ( idUsuario: 1 / Fecha: 2019-09-14 00:25:15) - ( idUsuario: 1 / Fecha: 2019-09-14 00:41:58) - ( idUsuario: 1 / Fecha: 2019-09-13 23:31:12) - ( idUsuario: 1 / Fecha: 2019-09-13 23:44:04)'),
(3, 1, 3, 1, 1, 2, 4.00, 3.01, '2019-09-11 00:11:10', '- ( idUsuario: 1 / Fecha: 2019-09-14 00:25:52) - ( idUsuario: 1 / Fecha: 2019-09-14 00:43:20)'),
(4, 1, 3, 1, 1, 2, 1.00, 1.22, '2019-09-11 00:11:27', '- ( idUsuario: 1 / Fecha: 2019-09-11 22:35:08) - ( idUsuario: 1 / Fecha: 2019-09-12 00:03:05) - ( idUsuario: 1 / Fecha: 2019-09-12 06:04:27) - ( idUsuario: 1 / Fecha: 2019-09-12 06:35:54) - ( idUsuario: 1 / Fecha: 2019-09-12 06:41:00) - ( idUsuario: 1 / Fecha: 2019-09-12 06:50:14) - ( idUsuario: 1 / Fecha: 2019-09-12 07:15:54) - ( idUsuario: 1 / Fecha: 2019-09-12 07:17:13) - ( idUsuario: 1 / Fecha: 2019-09-12 21:15:34) - ( idUsuario: 1 / Fecha: 2019-09-13 05:34:45) - ( idUsuario: 1 / Fecha: 2019-09-13 14:43:11) - ( idUsuario: 1 / Fecha: 2019-09-13 23:49:14) - ( idUsuario: 1 / Fecha: 2019-09-14 00:00:14) - ( idUsuario: 1 / Fecha: 2019-09-14 00:01:41) - ( idUsuario: 1 / Fecha: 2019-09-14 00:30:10) - ( idUsuario: 1 / Fecha: 2019-09-14 00:30:29)'),
(5, 1, 3, 5, 1, 2, 3.00, 10.00, '2019-11-06 21:10:57', ''),
(6, 1, 3, 5, 1, 3, 10.00, 50.00, '2019-11-06 21:27:11', ''),
(7, 1, 3, 5, 1, 3, 30.00, 10.00, '2019-11-06 21:27:33', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notassalidas`
--

CREATE TABLE `notassalidas` (
  `idNotaSalida` int(11) NOT NULL,
  `idUsuario` int(11) DEFAULT NULL,
  `idTipo` int(11) DEFAULT NULL,
  `idProducto` int(11) DEFAULT NULL,
  `idUnidad` int(11) DEFAULT NULL,
  `idEmpresa` int(11) DEFAULT NULL,
  `numeroSacos` float(5,2) DEFAULT NULL,
  `cantidad` float(5,2) DEFAULT NULL,
  `fechaNotaSalida` datetime DEFAULT NULL,
  `seguimiento` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `notassalidas`
--

INSERT INTO `notassalidas` (`idNotaSalida`, `idUsuario`, `idTipo`, `idProducto`, `idUnidad`, `idEmpresa`, `numeroSacos`, `cantidad`, `fechaNotaSalida`, `seguimiento`) VALUES
(1, 1, 3, 1, 1, 2, 1.00, 1.39, '2019-09-11 22:01:28', '- ( idUsuario: 1 / Fecha: 2019-09-11 22:04:58) - ( idUsuario: 1 / Fecha: 2019-09-11 22:05:10) - ( idUsuario: 1 / Fecha: 2019-09-11 22:27:02) - ( idUsuario: 1 / Fecha: 2019-09-12 00:01:58)'),
(2, 1, 3, 5, 1, 2, 1.00, 1.55, '2019-09-12 00:01:14', '( idUsuario: 1 / Fecha: 2019-09-12 00:01:14) - ( idUsuario: 1 / Fecha: 2019-09-12 00:02:34) - ( idUsuario: 1 / Fecha: 2019-09-12 07:01:11) - ( idUsuario: 1 / Fecha: 2019-09-12 07:01:26) - ( idUsuario: 1 / Fecha: 2020-04-23 03:15:10)');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `idProducto` int(11) NOT NULL,
  `producto` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`idProducto`, `producto`) VALUES
(2, 'cacao'),
(5, 'cacao chuncho'),
(3, 'Cacao chuncho fermentado'),
(4, 'Cacao hibrido fermentado'),
(1, 'Café pergamino seco');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

CREATE TABLE `tipos` (
  `idTipo` int(8) NOT NULL,
  `tipo` varchar(60) NOT NULL,
  `tabla` varchar(60) DEFAULT NULL,
  `publicado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`idTipo`, `tipo`, `tabla`, `publicado`) VALUES
(1, 'Agricultor/Proveedor', 'personas', '1'),
(2, 'Clientes', 'personas', '1'),
(3, 'Nota de ingreso', 'almacenMateriaPrima', '1'),
(4, 'Nota salida', 'almacenMateriaPrima', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `unidades`
--

CREATE TABLE `unidades` (
  `idUnidad` int(5) NOT NULL,
  `unidad` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `unidades`
--

INSERT INTO `unidades` (`idUnidad`, `unidad`) VALUES
(1, 'Unidad');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `cedula` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `cargo` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `usuario` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `password2` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `pregunta` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `respuesta` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `nivel` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `fecha_ingreso` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `cedula`, `cargo`, `usuario`, `password`, `password2`, `pregunta`, `respuesta`, `nivel`, `fecha_ingreso`) VALUES
(1, 'CHACMANI JIMENEZ WASHINGTON', '123', 'admin', '123', '123', '123', 'NOMBRE DE MASCOTA', 'perro', 'ADMINISTRADOR', '2017-03-13'),
(2, 'Luzgardo', '2', '2', '2', '2', '22', '2', '2', '2', '2019-09-12');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `almacenes`
--
ALTER TABLE `almacenes`
  ADD PRIMARY KEY (`idAlmacen`);

--
-- Indices de la tabla `empresas`
--
ALTER TABLE `empresas`
  ADD PRIMARY KEY (`idEmpresa`,`empresa`);

--
-- Indices de la tabla `notasingresos`
--
ALTER TABLE `notasingresos`
  ADD PRIMARY KEY (`idNotaIngreso`);

--
-- Indices de la tabla `notassalidas`
--
ALTER TABLE `notassalidas`
  ADD PRIMARY KEY (`idNotaSalida`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`idProducto`),
  ADD UNIQUE KEY `articulo` (`producto`) USING BTREE;

--
-- Indices de la tabla `tipos`
--
ALTER TABLE `tipos`
  ADD PRIMARY KEY (`idTipo`);

--
-- Indices de la tabla `unidades`
--
ALTER TABLE `unidades`
  ADD PRIMARY KEY (`idUnidad`,`unidad`),
  ADD UNIQUE KEY `marca` (`unidad`) USING BTREE;

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `almacenes`
--
ALTER TABLE `almacenes`
  MODIFY `idAlmacen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `empresas`
--
ALTER TABLE `empresas`
  MODIFY `idEmpresa` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `notasingresos`
--
ALTER TABLE `notasingresos`
  MODIFY `idNotaIngreso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `notassalidas`
--
ALTER TABLE `notassalidas`
  MODIFY `idNotaSalida` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `idProducto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tipos`
--
ALTER TABLE `tipos`
  MODIFY `idTipo` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `unidades`
--
ALTER TABLE `unidades`
  MODIFY `idUnidad` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
