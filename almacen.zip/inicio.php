<?php
require 'config/htmlCabeza.php';
?>

<div class="col-sm-9">
	<h1>Bienvenido   <?php echo $nombreUsuario;?> </h1>
</div>

<?php
require 'config/htmlPie.php';
?>
