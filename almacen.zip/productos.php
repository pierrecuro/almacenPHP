<?php
require 'config/htmlCabeza.php'; 
require_once("clases/productos.php"); 
//print_r( $_POST );  
//print_r( $_GET);  
$interfaces=new Productos(); 
$datos=$interfaces->listarProductos();
if(isset($_GET["idProducto"])){ $info=$interfaces->seleccionarProductos($_GET["idProducto"]); } 
if(isset($_POST["Guardar"])){ $interfaces->guardarProductos(); } 
if(isset($_POST["Editar"])){ $interfaces->editarProductos(); }  
?>


<!-- Inicio Formulario  -->
<div class="col-lg-6">
    <div class="card">
        <div class="card-header">Producto</div>
        <div class="card-body card-block">
            <form action="" method="post" class="">
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon"><i class="fa fa-user"></i></div>
                        <input type="text" id="productos" name="producto" placeholder="producto"
                        <?php if(isset($_GET["idProducto"])){ echo "value='".$info[0]["producto"]."'"; }?>
                        class="form-control" required="required">
                    </div>
                </div>
                <div class="form-actions form-group">
                    <?php if(isset($_GET["idProducto"])){ ?>
                        <input type="hidden"  name="idProducto" value="<?php echo $info[0]["idProducto"]; ?>"  >
                        <button type="submit" class="btn btn-success btn-sm" name="Editar">Editar</button>
                    <?php } else {?>
                    <button type="submit" class="btn btn-success btn-sm" name="Guardar">Guardar</button>
                    <?php } ?>
            	</div>
            </form>
        </div>
    </div>
</div>
<!-- Fin Formulario  -->


<!-- Inicio Contenidos  -->
        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Listado de la producto</strong>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr> 
                                            <th>productos</th> 
                                            <th>Editar</th> 
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php for($i=0;$i<sizeof($datos);$i++){?> 
                                         <tr> 
                                            <td><?php echo $datos[$i]["producto"];?></td> 
                                       <td><a href='productos.php?idProducto=<?php echo $datos[$i]["idProducto"];?>'> Editar </a></td></tr>
                                        <?php } ?>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
<!-- Final Contenidos  -->

<?php
require 'config/htmlPie.php';
?>
