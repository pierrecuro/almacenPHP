<?php
require 'config/htmlCabeza.php'; 
require_once("clases/empresas.php"); 
//print_r( $_POST );  
//print_r( $_GET);  
$interfaces=new Empresas(); 
$datos=$interfaces->listarEmpresas();
if(isset($_GET["idEmpresa"])){ $info=$interfaces->seleccionarEmpresas($_GET["idEmpresa"]); } 
if(isset($_POST["Guardar"]) and $_POST["empresa"]!='' ){ $interfaces->guardarEmpresas(); } 
if(isset($_POST["Editar"])){ $interfaces->editarEmpresas(); }  

$rtipo=$interfaces->listarTipo(); 

?>


<!-- Inicio Formulario  -->
<div class="col-lg-8">
    <div class="card">
        <div class="card-header">Empresas</div>
        <div class="card-body card-block">
            <form action="" method="post" class="">

<div class="col-lg-6">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Selecciona  Categoria</strong>
        </div>
        <div class="card-body"> 

            <select name='idTipo'  class="standardSelect" >
                <?php for($i=0;$i<sizeof($rtipo);$i++){?>
                    <option value="<?php echo $rtipo[$i]["idTipo"];?>"  <?php if(isset($_GET["idEmpresa"])){ if ($info[0]["idTipo"]==$rtipo[$i]["idTipo"]){echo  "selected"; } }?>>
                    <?php echo $rtipo[$i]["tipo"];?> 
                    </option>
                <?php } ?> 
            </select>

        </div>
    </div>
</div>   
 

          

                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">Persona Natural o Juridica</div>
                        <input type="text" id="Empresas" name="empresa" placeholder="empresa"
                        <?php if(isset($_GET["idEmpresa"])){ echo "value='".$info[0]["empresa"]."'"; }?>
                        class="form-control" required="required">
                        <div class="input-group-addon"><i class="fa fa-user"></i></div>
                    </div>
                </div>
 
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">RUC</div>
                        <input type="text" id="ruc" name="ruc" placeholder="ruc"
                        <?php if(isset($_GET["idEmpresa"])){ echo "value='".$info[0]["ruc"]."'"; }?>
                        class="form-control" required="required">
                        <div class="input-group-addon"><i class="fa fa-pencil-square-o"></i></div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">Dirección</div>
                        <input type="text" id="Empresas" name="direccion" placeholder="direccion"
                        <?php if(isset($_GET["idEmpresa"])){ echo "value='".$info[0]["direccion"]."'"; }?>
                        class="form-control" required="required">
                        <div class="input-group-addon"><i class="fa fa-home"></i></div> 
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">Celular</div>                        
                        <input type="text" id="Empresas" name="celular" placeholder="celular"
                        <?php if(isset($_GET["idEmpresa"])){ echo "value='".$info[0]["celular"]."'"; }?>
                        class="form-control" required="required">
                        <div class="input-group-addon"><i class="fa fa-phone"></i></div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">Correo</div>  
                        <input type="text" id="Empresas" name="correo" placeholder="correo"
                        <?php if(isset($_GET["idEmpresa"])){ echo "value='".$info[0]["correo"]."'"; }?>
                        class="form-control" >
                        <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">Datos Adicionales</div>  
                        <input type="text" id="Empresas" name="datos" placeholder="datos"
                        <?php if(isset($_GET["idEmpresa"])){ echo "value='".$info[0]["datos"]."'"; }?>
                        class="form-control" >
                        <div class="input-group-addon"><i class="fa fa-comments-o"></i></div>
                    </div>
                </div>



                <div class="form-actions form-group">
                    <?php if(isset($_GET["idEmpresa"])){ ?>
                        <input type="hidden"  name="idEmpresa" value="<?php echo $info[0]["idEmpresa"]; ?>"  >
                        <button type="submit" class="btn btn-success btn-sm" name="Editar">Editar</button>
                    <?php } else {?>
                    <button type="submit" class="btn btn-success btn-sm" name="Guardar">Guardar</button>
                    <?php } ?>
            	</div>

            </form>
        </div>
    </div>
</div>
<!-- Fin Formulario  -->


<!-- Inicio Contenidos  -->
        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Listado de la empresa</strong>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th></th> 
                                            <th>Empresas</th> 
                                            <th>ruc</th> 
                                            <th>direccion</th> 
                                            <th>celular</th> 
                                            <th>correo</th>  
                                            <th>Editar</th> 
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php for($i=0;$i<sizeof($datos);$i++){?> 
                                         <tr>
                                            <td><?php echo $datos[$i]["tipo"];?></td> 
                                            <td><?php echo $datos[$i]["empresa"];?></td> 
                                            <td><?php echo $datos[$i]["ruc"];?></td> 
                                            <td><?php echo $datos[$i]["direccion"];?></td> 
                                            <td><?php echo $datos[$i]["celular"];?></td> 
                                            <td><?php echo $datos[$i]["correo"];?></td> 

                                       <td><a href='empresas.php?idEmpresa=<?php echo $datos[$i]["idEmpresa"];?>'> Editar </a></td></tr>
                                        <?php } ?>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
<!-- Final Contenidos  -->

<?php
require 'config/htmlPie.php';
?>
