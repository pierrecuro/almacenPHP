<?php 
require 'notaIngresoCabeza.php'; 
require '../config/config.php';
require_once("../clases/reportes.php"); 
//print_r( $_POST );  
//print_r( $_GET);  
$interfaces=new Reportes();  
$row=$interfaces->reportePDFNotaIngreso();


$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$nro=1;
for($i=0;$i<sizeof($row);$i++)
	{ 
		$pdf->Cell(25,6,utf8_decode($nro++),1,0,'C');  
		$pdf->Cell(110,6,utf8_decode($row[$i]['producto']),1,0,'T');
		$pdf->Cell(25,6,utf8_decode($row[$i]['numeroSacos']),1,0,'C');
		$pdf->Cell(23,6,utf8_decode($row[$i]['cantidad']),1,1,'C');
		//1,1 --> salto de linea

	}
	$pdf->Output();

?>
