<?php 
require 'reporteSaldoCabeza.php'; 
require '../config/config.php';
require_once("../clases/reportes.php"); 
//print_r( $_POST );  
//print_r( $_GET);  
$interfaces=new Reportes();  

$rni=$interfaces->reportePDFNotaIngreso();
$rns=$interfaces->reportePDFNotaSalida();
 

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$nro=1;
for($i=0;$i<sizeof($rni);$i++)
	{ 
		$pdf->Cell(25,6,utf8_decode("Ingreso"),1,0,'C');  
		$pdf->Cell(110,6,utf8_decode($rni[$i]['producto']),1,0,'T');
		$pdf->Cell(25,6,utf8_decode($rni[$i]['numeroSacos']),1,0,'C');
		$pdf->Cell(23,6,utf8_decode($rni[$i]['cantidad']),1,1,'C');
		$totalCantidadNI=$rni[$i]['cantidad'];
		//1,1 --> salto de linea 
	}
for($i=0;$i<sizeof($rns);$i++)
	{ 
		$pdf->Cell(25,6,utf8_decode("Salida"),1,0,'C');  
		$pdf->Cell(110,6,utf8_decode($rns[$i]['producto']),1,0,'T');
		$pdf->Cell(25,6,utf8_decode($rns[$i]['numeroSacos']),1,0,'C');
		$pdf->Cell(23,6,utf8_decode($rns[$i]['cantidad']),1,1,'C');
		$totalCantidadNS=$rns[$i]['cantidad'];
		//1,1 --> salto de linea 
	}

		$pdf->Cell(160,6,utf8_decode("Total"),1,0,'R');
		$pdf->Cell(23,6,utf8_decode($totalCantidadNI-$totalCantidadNS),1,1,'C');

	$pdf->Output();

?>
