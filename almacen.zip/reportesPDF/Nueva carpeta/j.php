<?php  
require 'notaIngresoCabeza.php'; 
require '../config/config.php';
require_once("../clases/reportes.php"); 
//print_r( $_POST );  
//print_r( $_GET);  
$interfaces=new Reportes();    
$rows=$interfaces->reporteDistinct();  

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

$j=1;$a=0;
for($i=0;$i<count($rows);$i++)
{ 
	$re=$interfaces->reporte($j); 
	$pdf->Cell(25,6,utf8_decode($j),1,0,'C');  
	$pdf->Cell(110,6,utf8_decode($re[$a]['productoStock']),1,0,'T');
	$pdf->Cell(25,6,utf8_decode($re[$a]['cantidadSacosDisponible']),1,0,'C');
	$pdf->Cell(23,6,utf8_decode($re[$a]['cantidadDisponible']),1,1,'C'); 
	$j++;
	$a=0;
} 
$pdf->Output(); 

?>
