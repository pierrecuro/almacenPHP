<?php
$arreglo[] = array(1,2);

$array = array(1, 2, 3, 4, 5);
//print_r($array);

$i=0;
while (count($array)>$i){
echo $array[$i]."<br>";
	$i++;
}


?>