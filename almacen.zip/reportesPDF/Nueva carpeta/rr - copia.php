<?php  
require '../config/config.php';
require_once("../clases/reportes.php"); 
//print_r( $_POST );  
//print_r( $_GET);  
$interfaces=new Reportes();   

$rows=$interfaces->reporteDistinct(); 


$j=1;
$a=0;
for($i=0;$i<count($rows);$i++)
{ 
	$re=$interfaces->reporte($j); 
	echo $re[$a]['productoStock']."<br>"; 
	echo $re[$a]['cantidadSacosDisponible']."<br>"; 
	echo $re[$a]['cantidadDisponible']."<br>"; 
	$j++;

$a=0;
}
 

/*
for($i=0;$i<sizeof($rows);$i++)
{ 
//echo $row[$i]['producto']."<br>";
$pdf->Cell(25,6,utf8_decode("STOCK"),1,0,'C');  
$pdf->Cell(110,6,utf8_decode($re[$i]['productoStock']),1,0,'T');
$pdf->Cell(25,6,utf8_decode($re[$i]['cantidadSacosDisponible']),1,0,'C');
$pdf->Cell(23,6,utf8_decode($re[$i]['cantidadDisponible']),1,1,'C');
}

$pdf->Output();
*/

?>
