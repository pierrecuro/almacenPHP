<?php 
require 'reporteSaldoCabeza.php'; 
require '../config/config.php';
require_once("../clases/reportes.php"); 
//print_r( $_POST );  
//print_r( $_GET);  
$interfaces=new Reportes();  
 

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$nro=1;

/*
$array = array(1, 2);

$i=0;
while (count($array)>$i){
//echo $array[$i]."<br>";

 
$re=$interfaces->reporte($array[$i]);

	$pdf->Cell(25,6,utf8_decode("STOCK"),1,0,'C');  
	$pdf->Cell(110,6,utf8_decode($re[$i]['productoStock']),1,0,'T');
	$pdf->Cell(25,6,utf8_decode($re[$i]['cantidadSacosDisponible']),1,0,'C');
	$pdf->Cell(23,6,utf8_decode($re[$i]['cantidadDisponible']),1,1,'C');
	//1,1 --> salto de linea 
 
	$i++; 
 } 
 */

 
$re=$interfaces->reporte();
 	$pdf->Cell(25,6,utf8_decode("STOCK"),1,0,'C');  
	$pdf->Cell(110,6,utf8_decode($re[0]['productoStock']),1,0,'T');
	$pdf->Cell(25,6,utf8_decode($re[0]['cantidadSacosDisponible']),1,0,'C');
	$pdf->Cell(23,6,utf8_decode($re[0]['cantidadDisponible']),1,1,'C');
/* 

DELIMITER $$
CREATE PROCEDURE stock(pIdproducto INT)
	BEGIN
		declare cantSacos_ingre decimal(5,2);
		declare cantidad_ingre decimal(5,2);
		declare cantSacos_sal decimal(5,2);
		declare cantidad_sal decimal(5,2);
		declare cantidadSacosDisponible decimal(5,2);
		declare cantidadDisponible decimal(5,2);
		
		declare productoStock nvarchar(250);

		SELECT SUM(numeroSacos) FROM notasingresos WHERE idProducto=pIdproducto INTO cantSacos_ingre;
		SELECT SUM(cantidad) FROM notasingresos WHERE idProducto=pIdproducto  INTO cantidad_ingre;
		SELECT SUM(numeroSacos) FROM notassalidas WHERE idProducto=pIdproducto INTO cantSacos_sal;
		SELECT SUM(cantidad) FROM notassalidas WHERE idProducto=pIdproducto  INTO cantidad_sal;

		SELECT producto FROM productos WHERE idProducto=pIdproducto  INTO productoStock;
		
		SET cantidadSacosDisponible=cantSacos_ingre-cantSacos_sal;
		SET cantidadDisponible=cantidad_ingre-cantidad_sal;
		SELECT productoStock,cantidadSacosDisponible,cantidadDisponible;
    END $$
DELIMITER ;



//SELECT producto_pro,cantSacos_ingre,cantidad_ingre,cantSacos_sal,cantidad_sal,cantidadSacosDisponible,cantidadDisponible;
CALL  stock(1)




DELIMITER $$
CREATE PROCEDURE stock2(pIdproducto INT)
	BEGIN
		declare cantSacos_ingre decimal(5,2);
		declare cantidad_ingre decimal(5,2);
		declare cantSacos_sal decimal(5,2);
		declare cantidad_sal decimal(5,2);
		declare cantidadSacosDisponible decimal(5,2);
		declare cantidadDisponible decimal(5,2); 
		declare productoStock nvarchar(250);

		SELECT IFNULL(SUM(numeroSacos), 0) FROM notasingresos ni JOIN productos p ON ni.idProducto=p.idProducto WHERE ni.idProducto=pIdproducto INTO cantSacos_ingre;
        
		SELECT IFNULL(SUM(cantidad), 0) FROM notasingresos ni JOIN productos p ON ni.idProducto=p.idProducto  WHERE ni.idProducto=pIdproducto  INTO cantidad_ingre;
        
		SELECT IFNULL(SUM(numeroSacos), 0) FROM notassalidas ns JOIN productos p ON ns.idProducto=p.idProducto  WHERE ns.idProducto=pIdproducto INTO cantSacos_sal;
        
		SELECT IFNULL(SUM(cantidad), 0) FROM notassalidas ns JOIN productos p ON ns.idProducto=p.idProducto  WHERE ns.idProducto=pIdproducto  INTO cantidad_sal;
        
		SELECT producto FROM productos WHERE idProducto=pIdproducto  INTO productoStock;
		
		SET cantidadSacosDisponible=cantSacos_ingre-cantSacos_sal;
		SET cantidadDisponible=cantidad_ingre-cantidad_sal;
		SELECT productoStock,cantidadSacosDisponible,cantidadDisponible;
    
        END $$
DELIMITER ;
    */



/*

SET i=0;
loop1: LOOP
SET i=i+1;
IF i>=10 THEN //Last number - exit loop
LEAVE loop1;
ELSEIF MOD(i,2)=0 THEN //Even number - try again
ITERATE loop1;
END IF;
SELECT CONCAT(i," is an odd number");
END LOOP loop1;

*/
 

	$pdf->Output();

?>
