<?php  
require '../config/config.php';
require_once("../clases/reportes.php"); 
//print_r( $_POST );  
//print_r( $_GET);  
$interfaces=new Reportes();   

$rows=$interfaces->reporteDistinct(); 

 
$i=0; 
while (count($rows)>$i)
{ 
	$varIdProducto=$rows[$i]['idProducto'];
	$re=$interfaces->reporte($varIdProducto);  
	echo $re[0]['productoStock']."<br>"; 
	echo $re[0]['cantidadSacosDisponible']."<br>"; 
	echo $re[0]['cantidadDisponible']."<br>"; 
 	$i++;
}  


/*

$array = array(1, 2, 3, 4, 5);
//print_r($array);

$i=0;
while (count($array)>$i){
echo $array[$i]."<br>";
	$i++;
}

*/

?>
