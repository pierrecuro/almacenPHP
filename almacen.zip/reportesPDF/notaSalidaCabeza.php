<?php
	
	require '../fpdf/fpdf.php';
	
	class PDF extends FPDF
	{
		function Header()
		{
			$this->Image('../images/cafe.png', 20, 5, 25 );
			$this->Image('../images/cacao.png', 160, 5, 25 );
			$this->SetFont('Arial','B',15);
			$this->Cell(30);
			$this->Cell(120,10, 'Reporte Notas de Salida',0,0,'C');
			$this->Ln(20);
			$this->SetFillColor(134,190,253);
			$this->SetFont('Arial','B',10);
			
			$this->Cell(25,6,' Nro',1,0,'C',1); 
			$this->Cell(110,6,'Producto',1,0,'C',1);
			$this->Cell(25,6,'Nro Sacos',1,0,'C',1);
			$this->Cell(23,6,'Cantidad',1,1,'C',1); 	

			$this->SetFont('Arial','',10); 
		}
		
		function Footer()
		{
			$this->SetY(-15);
			$this->SetFont('Arial','I', 8);
			$this->Cell(0,10, 'Pagina '.$this->PageNo().'/{nb}',0,0,'C' );
		}		
	}
?>
